# material_editor
Powerful 3D Material editor

Usage:
https://youtu.be/nCSctOX8RPw


![icon](/preview.png)



## Support

<a href="https://www.buymeacoffee.com/verdicted" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
